ファイルの説明
・departments : 部署
・facilities : 設備
・gantt_groups : 設備xユニットごとのグループデータ（よくわからなければ無でもOKです）
・holidays : 祝日
・milestones : マイルストーン
・operation_settings : 未使用
・processes : 工程
・ticket_users : 担当者設定
・tickets : ガントチャートの１行１行
・units : ユニット
・users : 担当者（パスワードはデフォルトを設定します）
※１行目にサンプルデータを残しています

その他
created_at, updated_at は空でよいです。
基本よくわからない項目は空でよいです。